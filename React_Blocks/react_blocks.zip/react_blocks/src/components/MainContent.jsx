import Subcontent from './Subcontent';
import Advertisement from './Advertisement';

function MainContent() {
    return (
        <div className="maincontent">
                <div className="subcontent"></div>
                <div className="subcontent"></div>
                <div className="subcontent"></div>
                <div className="advertisement"></div>
                </div>
        );
        }

export default MainContent