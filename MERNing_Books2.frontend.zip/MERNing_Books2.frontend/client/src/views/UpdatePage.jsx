import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

const UpdatePage = () => {
	const { id } = useParams();
	const [title, setTitle] = useState("");
	const [author, setAuthor] = useState("");
	const [pages, setPages] = useState("");
	const [isAvailable, setIsAvailable] = useState(false);
	const navigate = useNavigate("");
	const [error, setError] = useState(null);

	useEffect(() => {
		axios
			.get(`http://localhost:8001/api/books/${id}`)
			.then((response) => {
				const { title, author, pages, isAvailable } = response.data;
				setTitle(title);
				setAuthor(author);
				setPages(pages);
				setIsAvailable(isAvailable);
			})
			.catch((error) => console.log(error));
		
	}, [id]);

	const handleSubmit = (e) => {
		e.preventDefault();
		axios
			.put(`http://localhost:8001/api/books/${id}`, {
				title,
				author,
				pages,
				isAvailable,
			})
			.then((response) => {
				navigate("/");
			})
			.catch((error) => {
				console.log(error);
				setError(error.response.data.error);
			});
	};

	return (
		<div>
			<header id="customer">
				<h1>{title}</h1>
			</header>
			{/* Update Page inputs are set to prefill */}
			<div>
				<form onSubmit={handleSubmit}>
					<div>
						<label>Title:</label>
						<input
							type="text"
							name="title"
							value={title}
							onChange={(e) => setTitle(e.target.value)}
						
						/>
					</div>
					<div>
						<label>Author:</label>
						<input
							type="text"
							name="author"
							value={author}
							onChange={(e) => setAuthor(e.target.value)}
							
						/>
					</div>
					<div>
						<label>Pages:</label>
						<input
							type="number"
							name="pages"
							value={pages}
							onChange={(e) => setPages(e.target.value)}
							
						/>
					</div>
					<div>
						<label>Is Available</label>
						<input
							type="checkbox"
							name="isAvailable"
							checked={isAvailable} // "Checked" replaces "Value" for the checkbox
							onChange={(e) => setIsAvailable(e.target.checked)} // "Checked" replaces "Value" for the checkbox
						
						/>
					</div>
					<button>Update Book!</button>
				</form>
			</div>
		</div>
	);
};

export default UpdatePage;
