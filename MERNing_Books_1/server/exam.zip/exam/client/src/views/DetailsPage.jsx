import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const DetailsPage = () => {

    const { id } = useParams(); 
	const [storeList, setStoreList] = useState("");
    const [errors, setErrors] = useState({});
	const navigate = useNavigate();

   useEffect(() => {axios.get(`http://localhost:8001/api/stores/${id}`)
				.then((response) => setStoreList(response.data))
				.catch((errors) => console.log(errors));
   
		}, [id]);

        const handleSubmit = () =>{
        axios
					.put(`http://localhost:8001/api/stores/${id}`)
					.then((response) => {
						navigate("/");
					})
					.catch((errors) => console.log(errors));
    }



	return (
		<div>
			{storeList ? (
				<div>
					<h1>{storeList.name}</h1>
					<h1>{storeList.storeNumber}</h1>
					<h3>{storeList.isOpen ? "Open" : "Closed"}</h3>
				</div>
			) : (
				<h1>Loading...</h1>
			)}
		</div>
	);
}

export default DetailsPage;
