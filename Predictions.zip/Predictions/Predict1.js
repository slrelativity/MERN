// Problem 1
const cars = ['Tesla', 'Mercedes', 'Honda']
const [ randomCar ] = cars //[index0]
const [ ,otherRandomCar] = cars //[index0 ,index1]

//Predict the output
console.log(randomCar) //Telsa
console.log(otherRandomCar) //Mercedes



//The car in index 2 is skipped