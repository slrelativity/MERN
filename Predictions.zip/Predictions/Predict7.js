// Problem 7
function actuallyPrintingNames() {
    for (let index = 0; index < names.length; index++) {
    let name = names[index];
    console.log(name + ' was found at index ' + index);//No array present??
    }
    console.log('name and index after loop is ' + name + ':' + index);//No array present??
    }     