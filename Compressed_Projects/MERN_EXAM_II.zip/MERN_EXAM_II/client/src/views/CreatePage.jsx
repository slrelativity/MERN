import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";

const CreatePage = () => {
    const [name, setName] = useState("");
	const [age, setAge] = useState("");
	const [symptoms, setSymptoms] = useState("");
	const [errors, setErrors] = useState({});
	const navigate = useNavigate("");

    const submitHandler = (e) => {
		e.preventDefault();
		axios
			.post(`http://localhost:8001/api/patients/`, {name,	age, symptoms,})
			.then((response) => {	const newPatient = response.data;
				navigate("/patients");
			})
			.catch((errors) => {
				setErrors(errors.response.data.errors);
			});
	};

    return(
        <div>
			<header className="d-flex justify-content-space-between">
			<h1 className="m-2">Admit Patient</h1>
			</header>
			<div>
				<form onSubmit={submitHandler}>
                    <div className="border">
						<label className="form-label mx-2">Age</label>
							<input type="number" className="form-control mx-2" name="age" value={age} onChange={(e) => setAge(e.target.value)}/>
							{errors.age && <p>{errors.age.message}</p>}
					</div>
					<div>
						<label className="form-label">Name</label>
							<input type="text" className="form-control mx-2" name="name"value={name} onChange={(e) => setName(e.target.value)}/>
							{errors.name && <p>{errors.name.message}</p>}
					</div>
					<div>
						<label className="form-label mx-2">Symptoms</label>
							<textarea  name="symptoms" value={symptoms} onChange={(e) => setSymptoms(e.target.value)}/>
							{errors.symptoms && <p>{errors.symptoms.message}</p>}
					</div>
					<button className="create mx-1" onClick={submitHandler}>Admit</button>
				</form>
			</div>
		</div>
    ); 
};

export default CreatePage;
