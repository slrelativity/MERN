import { useState } from 'react'
import './App.css'
import Reactive from '../components/Reactive'

function App() {


  return (
    <>
    <Reactive/>
    </>
  )
}

export default App
