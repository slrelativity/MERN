import './App.css'
import GetPokemonList from './components/GetPokemonList'

function App() {


  return (
    <>
      <GetPokemonList/>
    </>
  )
}

export default App
