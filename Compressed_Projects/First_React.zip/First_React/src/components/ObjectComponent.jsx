const ObejctComponent = () =>{



    return(
        <>
        
        </>
    )
}

export default ObejctComponent
